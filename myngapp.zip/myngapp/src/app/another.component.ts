import { Component } from "@angular/core";

@Component({
    selector:'another',
    template:'<h1>Another</h1>'
})

export class AnotherComponent{}