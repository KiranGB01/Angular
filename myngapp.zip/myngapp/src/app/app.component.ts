import {Component} from '@angular/core';
@Component({
    selector:'app-root',
    templateUrl:'app.component.html',
    styleUrls:['app.component.css']
    
    
})
export class AppComponent{
    name:string;

    fruits:string[]=['Apple','Banana','Orange'];

    person={'name':'Ramesh','age':26};

    emps=[
        {'eid':101,'ename':'Ramesh','gender':'M','sal':50000,'retired':false,'doj':new Date('2021-02-04')},
        {'eid':102,'ename':'Sukrutha','gender':'F','sal':70000,'retired':true,'doj':new Date('2021-02-04')},
        {'eid':103,'ename':'Suresh','gender':'M','sal':50000,'retired':false,'doj':new Date('2021-02-04')},
        {'eid':104,'ename':'Karan','gender':'M','sal':50000,'retired':true,'doj':new Date('2021-02-04')},
        {'eid':105,'ename':'Ruby','gender':'F','sal':50000,'retired':false,'doj':new Date('2021-02-04')}
    ]
    constructor()
    {
        this.name='Ramesh';
    }
}