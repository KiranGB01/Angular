import {NgModule} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AnotherComponent } from './another.component';
import {AppComponent} from './app.component';
import { GenderPipe } from './gender.pipi';
import { NestedComponent } from './nested.component';
import { TaxPipe } from './tax.pipe';
import { AbcComponent } from './abc/abc.component';
import { TformComponent } from './tform/tform.component';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { SformComponent } from './sform/sform.component';
import { RformComponent } from './rform/rform.component';
import {HttpClientModule} from '@angular/common/http';
import { CallserviceComponent } from './callservice/callservice.component';

@NgModule({
    imports:[BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule], 
    declarations:[AppComponent,AnotherComponent,NestedComponent,GenderPipe,TaxPipe, AbcComponent, TformComponent, SformComponent, RformComponent, CallserviceComponent],
    bootstrap:[AppComponent,AnotherComponent]
})
export class AppModule{}