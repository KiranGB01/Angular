import { Component, OnInit } from '@angular/core';
import { MyService } from '../my.service';

@Component({
  selector: 'app-callservice',
  template: `
    <h1>Calling API</h1>
    <table>
       <tr *ngFor="let e of emps">
       <td>{{e.id}}</td>
       <td>{{e.name}}</td>
       <td>{{e.sal}}</td>
       </tr>
    </table>
    <form #empform2='ngForm' (ngSubmit)="onSubmit(empform2.value)">
    <input type="text" name="name" placeholder="ename" ngModel required><br>
    <input type="number" name="sal" placeholder="sal" ngModel required><br>
    <input type="submit" [disabled]="empform2.invalid">
  </form>

  <h3>Search, Update, Delete</h3>
  <form #empform3='ngForm' (ngSubmit)="search(empform3.value)">
    <input type="number" name="id" placeholder="eid" ngModel required><br>
    <input type="text" name="name" placeholder="ename" ngModel><br>
    <input type="number" name="sal" placeholder="sal" ngModel><br>
    <input type="submit" value="search">
  </form>
  {{emp|json}}
  
  `,
  styles: [
  ]
})
export class CallserviceComponent implements OnInit {
  emps:any;
  emp:any;
  constructor(private my:MyService) { 
    this.emp={id:0,name:'',sal:0};
  }

  ngOnInit(): void {
   this.my.getData().subscribe(d=>{this.emps=d;console.log('next')},e=>console.warn("ERROR",e),()=>console.log("complete"));
  }

  onSubmit(emp:any){
    console.log(emp);
    this.my.saveData(emp).subscribe(e=>{console.log(e);this.emps.push(e)});
  }

  
  search(data:any){
    this.my.getEmp(data.id).subscribe(e=>this.emp=e);
  }

}
