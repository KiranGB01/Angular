import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyService {

  constructor(private http:HttpClient) { }//DI

  getData(){
    return this.http.get('http://localhost:36089/api/empasync');
  }

  // getEmp(id:number){
  //   return this.http.get('http://localhost:36089/api/empasync'+id);
  // }

  saveData(emp:any){
    return this.http.post('http://localhost:36089/api/empasync',emp);
  }
 
  getEmp(id:number):Observable<Object>{
    return this.http.get('http://localhost:36089/api/empasync/'+id);
  }

}
