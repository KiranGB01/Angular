import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-rform',
  template: `
  <h1>Reactive Form Form</h1>
  
  <form [formGroup]="emprform" (ngSubmit)="onSubmit(emprform.value)">
    <input type="number" name="eid" placeholder="eid" formControlName="eid" required>
    <span style="color:red" *ngIf="emprform.controls.eid.errors?.required">Enter EID</span>
    <span style="color:red" *ngIf="emprform.controls.eid.errors?.eid">Enter EID between 101 and 115</span><br>
    <input type="text" name="ename" placeholder="ename" formControlName="ename">
    <span style="color:red" *ngIf="emprform.controls.ename.errors?.required">Enter Name</span>
    <span style="color:red" *ngIf="emprform.controls.ename.errors?.pattern">Enter valid Name</span><br>
    <input type="submit" [disabled]="emprform.invalid">
  </form>
  `,
  styles: [
  ]
})
export class RformComponent implements OnInit {
  emprform:FormGroup;
  constructor() { 
    this.emprform=new FormGroup({
      eid:new FormControl('',this.empIDValidator),//you can add the default values in the ()
        ename:new FormControl('',Validators.compose([ Validators.required,Validators.pattern('^[a-zA-Z]{2,10}$')]))
    })
  }

  ngOnInit(): void {
  }

  onSubmit(data:any){
    console.log(data);
  }
  empIDValidator(c:any){
    if(!c.value)
    return null;
    let id=c.value;
    if(id>=101 && id<=115)
    return null;
    else
    return {'eid':true}
  }

}
