import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sform',
  template: `
  <h1>Template Form of Student</h1>
  <h2>Hi {{name}}
  <form #stuform='ngForm' (ngSubmit)="onSubmit(stuform.value)">
    <input type="number" name="sid" placeholder="sid" ngModel><br>
    <input type="text" name="sname" placeholder="sname" [(ngModel)]="name"><br>
    <input type="number" name="marks" placeholder="marks" ngModel><br>
    <input type="submit">
  </form>
  `,
  styles: [
  ]
})
export class SformComponent implements OnInit {
  name:string='Kiran';
  constructor() { }

  ngOnInit(): void {
  }
  onSubmit(data:any){
    console.log(data);
  }

}
