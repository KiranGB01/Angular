import { Pipe,PipeTransform } from "@angular/core";

@Pipe({
    name:'tax'
})

export class TaxPipe implements PipeTransform{
    transform(a:number,r: number=0.1):number{

        let t=(a*r);
    return t;
    }
}