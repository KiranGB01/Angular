import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tform',
  template: `
    <h1>Template Form</h1>
    <h2>Hi {{name}}
    <form #empform='ngForm' (ngSubmit)="onSubmit(empform.value)">
      <input type="number" name="eid" placeholder="eid" ngModel required><br>
      <input type="text" name="ename" placeholder="ename" [(ngModel)]="name"><br>
      <input type="submit" [disabled]="empform.invalid">
    </form>
  `,
  styles: [
  ]
})
export class TformComponent implements OnInit {
  name:string='Kiran';
  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(data:any){
    console.log(data);
  }

}
